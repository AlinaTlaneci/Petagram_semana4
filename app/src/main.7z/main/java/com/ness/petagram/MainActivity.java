package com.ness.petagram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    SwipeRefreshLayout srlActualizar;
    ListView lvListaPlanetas;
    Adapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        agregarFavoritos();
        toastAveer();

        srlActualizar = findViewById(R.id.srlActualizar);
        lvListaPlanetas = findViewById(R.id.lvListaPlanetas);

        String[] planetas = getResources().getStringArray(R.array.planetas);
        lvListaPlanetas.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, planetas));
        srlActualizar.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refrescandoContenido();
            }
        });
    }

    public void refrescandoContenido(){
        String[] planetas = getResources().getStringArray(R.array.planetas);
        lvListaPlanetas.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, planetas));
        srlActualizar.setRefreshing(false);
    }

    public void toastAveer(){
        Button aVeer = (Button) findViewById(R.id.btnRaisedButton);
        aVeer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(), getResources().getString(R.string.txt_btn), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void agregarFavoritos(){
        FloatingActionButton miFAB = (FloatingActionButton) findViewById(R.id.fabEstrellita);
        miFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v, getResources().getString(R.string.txt_snackbar),Snackbar.LENGTH_SHORT)
                        .setAction(getResources().getString(R.string.txt_click_snackbar), new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Log.i("SNACKNAR", "Click en Snackbar");
                            }
                        })
                        .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                        .show();
            }
        });
    }
}